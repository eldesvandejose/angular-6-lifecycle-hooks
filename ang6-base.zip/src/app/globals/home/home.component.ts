import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'a6b-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {

  constructor() { }

  ngOnInit() {
    $(document).prop('title', 'Inicio');
  }

  ngOnDestroy() {
    console.log('Componente destruido');
  }
}
