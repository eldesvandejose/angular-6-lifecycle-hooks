import { Component, DoCheck } from '@angular/core';

@Component({
  selector: 'a6b-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements DoCheck {
  public lastEdited: string;

  constructor () { }

  ngDoCheck() {
    this.lastEdited = sessionStorage.getItem('LastEditedName');
  }
}
