<?php
  header('Access-Control-Allow-Origin: *');
  header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
  header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
  header('content-type: application/json; charset=utf-8');
  try {
      $conexion = new PDO('mysql:host=localhost;dbname=ang_a6b_miembros;charset=UTF8', 'root', '');
      $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch (PDOException $e) {
      echo 'Se ha producido una excepción: '.$e->getMessage();
      die();
  }
?>
