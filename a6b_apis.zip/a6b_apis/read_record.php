<?php
  include_once ('db_conn.php');

  // Recuperamos el id recibido por get del miembro que vamos a leer.
  $id = $_GET['id'];

  $consulta = "SELECT * FROM socios ";
  $consulta .= "WHERE id='".$id."';";
  $hacerConsulta = $conexion->query($consulta);
  $member = $hacerConsulta->fetch(PDO::FETCH_ASSOC);
  $hacerConsulta->closeCursor();

  $memberJson = json_encode($member);
  echo $memberJson;
?>
